# This script runs BashSlide from any directory with its text files
# It runs a subshell without changing the current working directory
(cd ~/Dev/BashSlide/bin/Release/ && ./BashSlide)
